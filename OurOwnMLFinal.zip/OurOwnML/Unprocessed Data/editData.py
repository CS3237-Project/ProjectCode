import numpy as np
import tensorflow as tf
from tensorflow import keras
import pandas as pd

column_names = ['activity', 'acc_x_axis', 'acc_y_axis', 'acc_z_axis','probability']
df = pd.read_csv('IMUAngleWalkingYZ.txt', header=None, names=column_names)
print(df.shape)
f = open("/mnt/c/Users/Siew Yang Zhi/Desktop/Arduino Code/ProcessedData.txt", "a")
for index, row in df.iterrows():
    #print("abc")
    f.write(str(row['activity'])+","+str(row['acc_x_axis'])+","+str(row['acc_y_axis']) + "\n")
    #print(row['activity'], row['acc_x_axis'],row['acc_y_axis'],row['acc_z_axis'],row['probability'])
f.close()
